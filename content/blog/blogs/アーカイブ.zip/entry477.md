---
title: 当ブログをGatsby v4 にアップグレードしました
date: 2021-12-12
hero: entry477.jp
pagetype: blog
cateId: 'web-developer'
tags: ["Gatsby","React","JavaScript"]
description: 昨年7月から進めていたウェブサイトのリニューアルがようやく終わりました。WebP対応しつつv3にupgradeする予定たったのですが、Gatsby cliでのインストールのエラーでひっかかって、
lead: ["プログラミングで事務作業を自動化してラクしよう！","前回に続き、Google Apps Scriptを使ってファイルを管理する方法を紹介します。 この記事では1.スプシ（Googleスプレッドシート）からファイルアップロード
2.ルール通りにファイルをリネーム保存 3.スプシにファイル情報を自動で追記する方法を解説します。"]
---

sudo npm -g i sharp
sudo npm -g i cordova-res

sudo npm install node-addon-api -g
npm cache clean --force
sudo npm i
npm cache clean --force
