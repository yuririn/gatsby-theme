---
title: 第1回 concrete5勉強会 in 広島
date: 2014-07-24
hero: thumbnail/2014/entry175.jpg
pagetype: blog
cateId: 'cms'
tags: ["concrete5"]
description: 第一回広島でのconcrete5の勉強会をまとめです。当日は中四国でconcrete5の勉強ができるということで遠くははるばる山口からお越しいただきました。その日のスライドのまとめをUPします。
lead: ["フロントエンドエンジニアのかみーゆです！","第1回広島でのconcrete5の勉強会をまとめです。","当日は中四国でconcrete5の勉強ができるということで遠くははるばる山口からお越しいただきました。","その日のスライドのまとめをUPします。"]
---
## モットーは初心者でもOK
今回は初心者でも気軽に参加できるよう、開発環境を整えるところからスタートしました。

参加者は4名でした。アットホームで質問しやすいということで喜ばれました♪

* 環境設定
* インストール方法
* 基本操作
* ブロックの紹介
詳しくは[concrete5勉強会inHIROSHIMAのスライド](https://www.slideshare.net/yurikamimori/concrete5-in-hiroshima)をご覧ください。

## 次回の勉強会
8/30（土）14:00～Movin' onにて行います。

お申し込みはDoorkeeperからどうぞ♪
